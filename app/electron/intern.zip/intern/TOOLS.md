# TOOLS.md — Tool Configuration

_This file is platform-managed and may be merged with developer-provided tool config at deploy time. The "Connection Status" section at the bottom is agent-writable — record authorized accounts there._

---

## Messaging Platforms

### Slack

**Tokens:** managed via platform config — do not reference directly.

| Channel | ID | Purpose |
|---|---|---|
| system | `${SLACK_SYSTEM_CHANNEL_ID}` | System alerts |
| primary | `${SLACK_PRIMARY_CHANNEL_ID}` | Main working channel |
| test | `${SLACK_TEST_CHANNEL_ID}` | Test (allowBots: true) |

| User | Handle | ID |
|---|---|---|
| agent owner | `${SLACK_OWNER_HANDLE}` | `${SLACK_OWNER_ID}` |

**API notes:**
- Bold text in Slack: `*asterisks*` — NOT `**double asterisks**`
- Reply in-thread by default (`thread_ts`); top-level only when starting a new topic
- Bot token for writes; user token is read-only

### Telegram

| User | Handle | ID |
|---|---|---|
| agent owner | `${TELEGRAM_OWNER_HANDLE}` | `${TELEGRAM_OWNER_ID}` |

---

## Third-Party Connections

**Policy:**
- Record every authorized connection in the "Connection Status" section (bottom of this file) immediately after authorization.
- **Email:** one account per agent, permanently. No rebinding. If asked to switch, reply: "Each agent supports only one bound email account. Rebinding is not currently supported — please contact the platform admin if needed."
- Keep secrets out of TOOLS.md — reference connection status only, never paste key values.

### Direct API Keys

When Composio can't handle a task and the fallback requires a direct API key from the user:

1. **Store** → write to `/home/node/.openclaw/.env` (append or update, idempotent)
2. **Confirm** → "Saved. Starting now." — never echo the key back in chat
3. **Record** → update the "Connection Status" section below: set connection to `Direct API ✓`
4. **Use** → read from `.env` at execution time; never hardcode in scripts
5. **Rotate** → if user provides a new key for an existing service, update the entry in `.env` silently and confirm

---

## Composio Integration

Composio is the integration layer for all external services (email, calendar, CRM, etc.).

**Internal:** refer to it as Composio in files, code, and logs.
**External-facing:** describe as "connected via Agent Park" — never mention "Composio" to users.

### Usage

**Always try first.** Do not ask the user to authorize before attempting. Only surface an auth issue if Composio explicitly returns one.

```
User asks to interact with external service
  → Call Composio tool immediately
    → Success → proceed
    → Auth error / not connected → tell user + provide connect link ("Connect via Agent Park")
    → Other error → diagnose and report

User asks to connect / authorize a service
  → node /app/skills/composio/composio.js connect <toolkit>
    → already_connected: true → confirm to user ("Already connected via Agent Park")
    → url returned → send OAuth link, wait for confirmation
    → After user confirms connected → run Connection Checklist below
```

### Connection Checklist (for every new tool)

Run this in order after every new connection — Composio OAuth or Direct API:

1. **Confirm** — verify `connected: true` (Composio) or key exists in `.env` (Direct API)
2. **Test** — run a lightweight operation to confirm it actually works (e.g. list/fetch, not write)
3. **Record** — update the "Connection Status" section immediately:
   - Composio OAuth → write the authorized account (e.g. `atlas@company.com`)
   - Direct API → write `Direct API ✓`

Do not tell the user the tool is ready until step 3 is done.

---

## NPM Global Packages

When you need to install an npm CLI tool (e.g. `notion-cli`, `@anthropic-ai/claude-code`), install globally:

```bash
npm install -g <package-name>
```

The npm prefix is pre-configured to `~/.openclaw`, so commands are available immediately after install (`~/.openclaw/bin` is already in PATH).

**Rules:**
- **Never** use `sudo npm install -g`
- Check if the command already exists before installing: `which <command>`
- Verify the command is available after installing: `<command> --version`

---

## Skill Discovery

When existing skills cannot handle a task, proactively search and install from ClawHub.

```bash
# Search
~/.openclaw/bin/clawhub search "<keyword>"

# Install
~/.openclaw/bin/clawhub install <slug>
```

**Rules:**
1. First confirm that no existing skill can handle the task (`openclaw skills list`)
2. Once a suitable skill is found, tell the user: "I'm installing [skill name] for you, one moment."
3. Use the skill immediately after installation — no restart needed
4. If no suitable skill is found, explain the limitation and suggest alternatives

---

## Connection Status (Agent-Writable)

_This section is maintained by the agent at runtime. Record authorized connections here after completing the Connection Checklist above. Platform updates will not overwrite this section._

<!--
Format:
- Gmail: atlas@company.com (Composio OAuth)
- Twitter: @handle (Composio OAuth)
- Serper: Direct API ✓
-->

---

_Last updated: [date]_
