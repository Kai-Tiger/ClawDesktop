#!/bin/sh
# Composio CLI wrapper — called by the agent via exec
# Usage:
#   composio.sh search "<use case>"
#   composio.sh exec <TOOL_SLUG> '<json args>' [session_id]
#   composio.sh schema <TOOL_SLUG> [session_id]
#
# Env vars (already set by openclaw):
#   COMPOSIO_API_KEY  — platform API key
#   COMPOSIO_USER_ID  — workspace/user id

BASE="https://backend.composio.dev/api/v3"
API_KEY="${COMPOSIO_API_KEY}"
USER_ID="${COMPOSIO_USER_ID}"

_post() {
  curl -sf -X POST "${BASE}$1" \
    -H "x-api-key: ${API_KEY}" \
    -H "Content-Type: application/json" \
    -d "$2"
}

case "$1" in
  search)
    USE_CASE="$2"
    _post "/tools/execute/COMPOSIO_SEARCH_TOOLS" \
      "{\"arguments\":{\"queries\":[{\"use_case\":\"${USE_CASE}\"}],\"session\":{\"generate_id\":true}},\"user_id\":\"${USER_ID}\"}"
    ;;

  exec)
    TOOL="$2"
    ARGS="$3"
    SESSION="${4:-}"
    SESSION_JSON=""
    [ -n "$SESSION" ] && SESSION_JSON=",\"session_id\":\"${SESSION}\""
    _post "/tools/execute/COMPOSIO_MULTI_EXECUTE_TOOL" \
      "{\"arguments\":{\"tools\":[{\"tool_slug\":\"${TOOL}\",\"arguments\":${ARGS}}],\"sync_response_to_workbench\":false${SESSION_JSON}},\"user_id\":\"${USER_ID}\"}"
    ;;

  schema)
    TOOL="$2"
    SESSION="${3:-}"
    SESSION_JSON=""
    [ -n "$SESSION" ] && SESSION_JSON=",\"session_id\":\"${SESSION}\""
    _post "/tools/execute/COMPOSIO_GET_TOOL_SCHEMAS" \
      "{\"arguments\":{\"tool_slugs\":[\"${TOOL}\"]${SESSION_JSON}},\"user_id\":\"${USER_ID}\"}"
    ;;

  *)
    echo "Usage: composio.sh search|exec|schema ..." >&2
    exit 1
    ;;
esac
