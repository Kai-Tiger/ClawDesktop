# USER.md — Agent Owner Profile & Access Control

_Initialized from a platform template on first deploy. Maintained by the agent afterward — never overwritten by the platform._

---

## Owner

- **Telegram User ID:** ${TELEGRAM_OWNER_USER_ID}
- **Slack User ID:**
- **Name:**
- **Preferred name:**
- **Timezone:**

---

## Preferences

_Fill in during onboarding and update over time as you learn more._

- **Communication style:** _e.g. brief vs. detailed, formal vs. casual_
- **Working style:** _e.g. async-first, prefers summaries, wants options before decisions_
- **Other notes:**

---

## Authorized Users

User IDs listed below are authorized to use this agent. The owner can add or remove entries at any time via conversation.

<!--
Format examples:
- 123456789  # Alice (Telegram)
- U012ABCDE  # Bob (Slack)
-->

---

## Management

The owner can manage the whitelist by messaging the agent directly:

- Add a user: `add [user_id] to whitelist`
- Remove a user: `remove [user_id] from whitelist`
- View whitelist: `list whitelist`

The agent will edit this file directly and confirm the result.
