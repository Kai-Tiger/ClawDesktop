# COMPANY.md — Company / Project Context (Optional)

_This file is optional. Include it when the agent serves a business or a specific project. If the agent serves an individual user with no business context, this file can be omitted._

_Sections 1–2 are auto-filled by the platform at deploy time. Sections 3 onward are owner-maintained — update them as the context evolves._

---

## 1. Basic Information

**Company Name:** ${COMPANY_NAME}

**Website:** ${COMPANY_WEBSITE}

**Industry:** ${COMPANY_INDUSTRY}

**Stage:** ${COMPANY_STAGE}

---

## 2. Product

**Product Name:** ${COMPANY_PRODUCT_NAME}

---

## 3. What the Product Does

_Not yet configured. Ask the agent owner to fill in:_
- _What problem it solves_
- _How it works_
- _Why it is different_

---

## 4. Target Audience

_Not yet configured. Ask the agent owner to fill in:_
- _Primary users_
- _Secondary users_
- _Customers vs end users (if different)_

---

## 5. Core Value Proposition

_Not yet configured. Ask the agent owner to fill in the 2–3 key outcomes the product delivers._

---

## 6. Goals

**Short-term:**
_Not yet configured._

**Long-term:**
_Not yet configured._

---

## 7. Competitive Landscape

**Main competitors:**
_Not yet configured._

**Why this product wins:**
_Not yet configured._

---

_Keep this file current. Stale context produces stale output._
_Last updated: [date]_
