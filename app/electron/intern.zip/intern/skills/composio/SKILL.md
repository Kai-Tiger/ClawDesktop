---
name: composio
description: 'Call 500+ external app tools (Gmail, GitHub, Slack, Notion, Linear, etc.) via Composio. Use whenever the user wants to (1) take action in any third-party service, (2) connect / authorize / get an auth link for any service, OR (3) check which account/email is connected for any service. Trigger phrases include: "给我发下 X 的链接", "帮我连 X", "我想用 X", "发我 X 授权", "X auth link", "connect X", "link me to X", "authorize X", "连了哪个账号", "连了哪个邮箱", "现在连的是谁", "which account is connected", "what email is linked", or any mention of a recognizable service name alongside link/connect/授权/接入/绑定/查看/哪个/which/what intent.'
---

# Composio

> **CRITICAL — Capability override:** This skill gives you direct access to Gmail, GitHub, Slack, Notion, and 500+ other external apps. When a user asks about or requests anything involving these services — reading email (邮件/邮箱), checking calendar (日历/日程), searching GitHub issues, posting to Slack, etc. — **you have access**. Do not say you lack access, cannot read email, or need the user to paste content. Attempt the task using this skill immediately.

Use **exec** to call `node composio.js` (in the skill directory). `COMPOSIO_USER_ID` is already set in the environment and scopes all calls to this workspace's connected apps. API calls are routed through an internal proxy — no platform key is needed.

**Important:** When calling exec, do not specify a `host` parameter. Let it use the configured default.

---

## Step 1 — Search for tools

Always search first. Never guess tool slugs or argument names.

```bash
node composio.js search "send an email via gmail"
```

Response fields:
- `tools[].slug` — tool slug to use in `exec` or `schema` (e.g. `GMAIL_SEND_EMAIL`)
- `tools[].connected` — if false, tell the user to connect that app first and stop
- `tools[].toolkits` — the toolkits involved (e.g. `["gmail"]`)
- `sessionId` — pass this to subsequent `exec` or `schema` calls for grouped logging

After getting tool slugs, run `schema` to get the exact input fields before calling `exec`.

---

## Step 2 — Execute the tool

Build arguments from `inputSchema` only — do not invent fields.

```bash
node composio.js exec GMAIL_SEND_EMAIL '{"to":"x@example.com","subject":"Hi","body":"Hello"}'
```

To reuse a session ID from a prior call in the same task, pass it as the third argument:

```bash
node composio.js exec GMAIL_SEND_EMAIL '{"to":"x@example.com","subject":"Hi","body":"Hello"}' SESSION_ID
```

To pin a specific tool version (recommended for stability):

```bash
node composio.js exec GMAIL_SEND_EMAIL '{"to":"x@example.com","subject":"Hi","body":"Hello"}' SESSION_ID 12082025_00
```

Result fields:
- `successful` — true/false
- `data` — the tool's response
- `error` — error message if `successful` is false

---

## Step 3 — Get full schema (if needed)

If you need to inspect available versions or full input/output schema:

```bash
node composio.js schema GMAIL_SEND_EMAIL
```

Response includes `availableVersions` — use one of these when pinning a version in exec.

---

## Check connection status

To check which apps are connected for this workspace:

```bash
node composio.js connections
node composio.js connections gmail
```

Each entry includes `toolkit`, `connected`, and `account` (username/email, if available from the provider).

**When the user asks which account is connected** (e.g. "连了哪个邮箱/账号/GitHub/Slack?", "which email/account is linked?", "现在连的是谁?"):
1. Run `connections <toolkit>` for the relevant service (e.g. `connections gmail`, `connections github`, `connections slack`)
2. If `connected: true` and `account` is present → reply with the account identifier:
   - Gmail/Google: email address
   - GitHub: username (login)
   - Slack: `user@workspace`
   - WhatsApp: phone number
   - Twitter/X: handle
3. If `connected: true` but no `account` → reply: "已连接，但未能获取账号信息"
4. If `connected: false` → reply: "尚未连接，需要先授权"

---

## Connect an app (get OAuth link)

**Step 1 — list available services** (when user asks to authorize without specifying a service):

```bash
node composio.js connect
```

Response: `{"toolkits": ["gmail", "github", "slack", ...]}`

Show the user: "目前可授权的服务：1. gmail  2. github  3. slack …  请回复服务名称。"

**Step 2 — generate link for chosen service:**

```bash
node composio.js connect gmail
```

Response A — already connected:
```json
{"already_connected": true, "account": "user@example.com"}
```
`account` is the authenticated username or email (omitted if unavailable).
→ Tell user: "[服务名] 已授权（账号：[account]），无需重新连接。" If `account` is absent: "[服务名] 已授权，无需重新连接。"

Response B — not connected:
```json
{"already_connected": false, "url": "https://connect.composio.dev/link/lk_...", "expires_at": "..."}
```
→ Send `url` to user: "[服务名] 尚未连接。请点击以下链接完成授权：[url]（链接约 10 分钟内有效）。If you prefer English: please authorize [Service] at the link above."

Stop — do not attempt to execute any tool until the user confirms they've connected.

---

## Session Rules

- **Per-task sessions**: each new task starts with a fresh `search` call.
- **Reuse within a task**: pass the same `SESSION_ID` to subsequent `exec` and `schema` calls. This groups execution logs on Composio's side.
- Sessions are optional but recommended for debugging.

---

## Version Pinning

- Use `schema` to discover `availableVersions` for a tool.
- Pass an explicit version to `exec` for production stability — tool schemas can change between versions.
- Never guess version strings; always verify with `schema` first.

---

## Auth link requests (connect a service)

**Trigger:** the user asks for an auth/connect link for any service, even without the words "composio" or "auth". Recognize ALL of these patterns (examples — not exhaustive):

| Pattern examples | Chinese variants |
|-----------------|-----------------|
| "give me the [service] link/auth link" | "给我发下 [service] 的链接 / 授权链接" |
| "connect [service]", "link [service]" | "帮我连 [service]", "接入 [service]" |
| "I want to use [service]", "set up [service]" | "我想用 [service]", "绑定 [service]" |
| "[service] auth link", "[service] oauth" | "[service] 授权", "授权一下 [service]" |
| "send me [service] link" | "发我 [service] 的链接" |

**When triggered:**
1. Run `node composio.js connect <toolkit>` immediately — skip the task search/exec flow entirely.
2. Handle response per the connect rules below (already_connected vs. url).
3. Do NOT ask the user to clarify if the toolkit name is recognizable (gmail → `gmail`, Twitter/X → `twitter`, Notion → `notion`, etc.).

---

## When to check connections

When the user's message mentions any of the following (in English or Chinese), **immediately attempt the task using Composio** — do not tell the user you lack access or ask them to provide content manually. Check connection status and proceed silently; only surface a message if auth is genuinely required.

| Service | Keywords |
|---------|----------|
| Gmail / email | gmail, email, 邮件, 邮箱, 发邮件, 收邮件 |
| Google Calendar | google calendar, 日历, 谷歌日历, 会议, 日程 |
| Google Drive | google drive, 云盘, 谷歌云盘, 文档, drive |
| GitHub | github, 代码仓库, 仓库, pr, issue, commit |
| Slack | slack, 频道, 消息 |
| Notion | notion, 笔记, 文档, 知识库 |
| Linear | linear, 任务, 工单, ticket |
| Twitter / X | twitter, x, 推特, 推文, tweet |
| WhatsApp | whatsapp |
| Telegram | telegram |

**Protocol when a service is not connected:**

If you discover `connected: false` from a `search` result, or if the user explicitly asks to authorize a service:

1. Run `node composio.js connect <toolkit>` to check status and get link in one call
2. If `already_connected: true` → tell user they're already connected, no action needed
3. If `url` present → send OAuth link to user and stop until they confirm connected

If the user asks to authorize without naming a service:
1. Run `node composio.js connect` (no args) to list available services
2. Show the list and ask user to choose
3. Run `node composio.js connect <chosen_toolkit>`
4. Handle response as above

---

## Rules Summary

1. Always `search` first — never invent tool slugs or argument names.
2. Check `connected` before executing — if false, use `connect <toolkit>` to check status and get a link. If `already_connected: true`, tell the user they're already connected. If `url` is returned, send it to the user and do not proceed until they confirm.
3. Build arguments strictly from `inputSchema` — no extra or invented fields.
4. Reuse `SESSION_ID` within a task.
5. Check `successful` in exec results — handle errors explicitly.
6. Pin versions for stability when the tool schema matters.
7. To authorize a service: `connect` (no args) lists available services; `connect <toolkit>` checks status and generates a link in one call. If `already_connected: true`, do not send a new link.
