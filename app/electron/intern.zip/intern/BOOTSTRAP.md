# BOOTSTRAP.md — Onboarding Guide

_This file exists because this is a fresh deployment. Complete the steps below, then delete this file._

---

## Step 1 — Determine Mode

Check `USER.md`:

- **Owner field is empty** → this is a **new user**. Run the full onboarding flow (Step 2a → Step 3 if applicable → Step 4).
- **Owner field is already set** → this is a **returning user** (re-deploy or agent update). Skip to Step 2b, then continue through Steps 3–5 as needed.

---

## Step 2a — New User: Introduce and Learn

Introduce yourself based on `IDENTITY.md` (your name, role, and what you can help with).

Then, in a natural conversation (not a form), learn:

- What to call them and how they prefer to be addressed
- Their timezone
- Any working style preferences (e.g. brief vs. detailed, async-first, etc.)

Record everything in `USER.md` as you go. Don't ask all at once — let it come up naturally.

---

## Step 2b — Returning User: Brief Re-Introduction

Acknowledge the prior context:

> "Welcome back — I've got your profile from last time. I'm [name from IDENTITY.md], your [role from IDENTITY.md]. Let me quickly make sure everything is still up to date."

Confirm:
- Their name and preferences are still accurate in `USER.md`
- Ask if anything has changed that you should know about

---

## Step 3 — Fill Company Context (Optional)

_Skip this step if the agent serves an individual user rather than a business._

If `COMPANY.md` exists, open it and check sections 3–7. For each section marked `_Not yet configured._`, ask the agent owner to fill it in — **one section at a time**, not all at once.

Priority order:
1. What the product does (Section 3) — needed for almost everything
2. Target audience (Section 4) — needed for any messaging work
3. Core value proposition (Section 5)
4. Goals (Section 6)
5. Competitive landscape (Section 7)

Update `COMPANY.md` with each answer as it comes in. It's fine to stop partway and continue later — incomplete is better than wrong.

---

## Step 4 — Connect Additional Tools

The messaging channel (Telegram or Slack) is already connected at deploy time.

Open `TOOLS.md` and review what additional third-party services this agent type might need (email, calendar, Notion, etc.). For each service that is not yet connected:

1. Run: `node /app/skills/composio/composio.js connect <toolkit>`
2. If already connected → confirm to user and move on
3. If not connected → send the OAuth link ("Connect via Agent Park") and wait for authorization
4. Once authorized → record in the "Connection Status" section of `TOOLS.md`

Do not block onboarding on tool connections — if the user wants to skip one, note it as pending and move on.

---

## Step 5 — Done

Summarize what was set up:
- What you now know about the user
- Which company context fields are filled vs. still pending (if applicable)
- Which tools are connected vs. pending

Then delete this file.

---

_Onboarding is not a one-time event. USER.md (and COMPANY.md, if applicable) should stay current as the relationship evolves._
