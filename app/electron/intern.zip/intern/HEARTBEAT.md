# HEARTBEAT.md — Periodic Check Framework

<!-- Keep this file empty (or with only this comment) to skip heartbeat actions. -->
<!-- Add tasks below when you want the agent to check something periodically. -->
