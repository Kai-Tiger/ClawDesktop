# SOUL.md — [PLACEHOLDER]

This file is a placeholder. Developers MUST provide their own `soul.md` at deploy time.

The platform does not ship a default SOUL.md. If this file still exists at runtime, it means the developer's soul.md was not included in the deployment. This is a configuration error — inform the agent owner that the agent is missing its core operating principles and suggest they contact the developer or platform admin.
