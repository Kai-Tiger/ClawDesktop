#!/usr/bin/env node
'use strict';

// Composio skill for openclaw.
// Calls are routed through the trigger server proxy (COMPOSIO_BASE_URL),
// which injects the platform API key. No API key is needed in this pod.
//
// Usage:
//   node composio.js search "<use case>"
//   node composio.js exec <TOOL_SLUG> '<json args>'
//   node composio.js schema <TOOL_SLUG>
//   node composio.js connections [toolkit_slug]
//   node composio.js connect <toolkit_slug>

const baseUrl     = process.env.COMPOSIO_BASE_URL || 'https://backend.composio.dev';
const userId      = process.env.COMPOSIO_USER_ID;
const podName     = process.env.MY_POD_NAME || '';
const workspaceId = process.env.WORKSPACE_ID || '';

if (!userId) {
  console.error(JSON.stringify({ error: 'COMPOSIO_USER_ID not set' }));
  process.exit(1);
}

const API = baseUrl + '/api/v3';

// Extract human-readable account identifier from a connected_accounts item.
// The Composio API stores OAuth token data in `data` / `state.val`.
// For Google OAuth the email is in the id_token JWT payload.
function extractAccount(a) {
  const d = a.data || a.state?.val || {};
  // Google / OIDC: decode id_token JWT payload to get email
  if (d.id_token) {
    try {
      const part = d.id_token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      const payload = JSON.parse(Buffer.from(part, 'base64').toString('utf8'));
      if (payload.email) return payload.email;
    } catch {}
  }
  // Other services: direct fields in data
  const slackAccount = d.team_name
    ? (d.user_name ? `${d.user_name}@${d.team_name}` : d.team_name)
    : null;
  return d.email || d.username || d.login   // generic / GitHub
    || slackAccount                          // Slack
    || d.user_name                           // Slack fallback
    || d.phone_number                        // WhatsApp
    || d.handle || d.screen_name             // Twitter/X
    || null;
}

function baseHeaders() {
  const h = { 'Content-Type': 'application/json', 'X-Composio-User-ID': userId };
  if (podName) h['X-Pod-Name'] = podName;
  if (workspaceId) h['X-Workspace-ID'] = workspaceId;
  return h;
}

async function post(path, body) {
  const res = await fetch(API + path, {
    method: 'POST',
    headers: baseHeaders(),
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Composio ${path}: ${res.status} ${text}`);
  return JSON.parse(text);
}

const [, , cmd, ...args] = process.argv;

// search "<use case>"
// Returns tool slugs with connection status. Use schema to get input fields.
async function search(query) {
  if (!query) throw new Error('query is required');
  const data = await post('/tools/execute/COMPOSIO_SEARCH_TOOLS', {
    arguments: { queries: [{ use_case: query }] },
    user_id: userId,
  });
  const results = data.data?.results || [];
  const connectionStatuses = data.data?.toolkit_connection_statuses || [];
  const connectedToolkits = new Set(
    connectionStatuses.filter(s => s.has_active_connection).map(s => s.toolkit)
  );
  // Flatten results into a tool list with connection status
  const tools = results.flatMap(r => {
    const slugs = [...(r.primary_tool_slugs || []), ...(r.related_tool_slugs || [])];
    return slugs.map(slug => ({
      slug,
      useCase: r.use_case,
      guidance: r.execution_guidance,
      toolkits: r.toolkits || [],
      connected: (r.toolkits || []).some(tk => connectedToolkits.has(tk)),
    }));
  });
  const sessionId = data.data?.session?.id;
  console.log(JSON.stringify({ tools, sessionId }, null, 2));
}

// exec <TOOL_SLUG> '<json args>' [SESSION_ID] [VERSION]
async function exec(toolSlug, argsJson, sessionId, version) {
  if (!toolSlug) throw new Error('tool slug is required');
  if (!argsJson) throw new Error('arguments JSON is required');
  const tool = { tool_slug: toolSlug, arguments: JSON.parse(argsJson) };
  if (version) tool.version = version;
  const body = {
    arguments: { tools: [tool], sync_response_to_workbench: false },
    user_id: userId,
  };
  if (sessionId) body.session_id = sessionId;
  const data = await post('/tools/execute/COMPOSIO_MULTI_EXECUTE_TOOL', body);
  console.log(JSON.stringify(data, null, 2));
}

// schema <TOOL_SLUG>
async function schema(toolSlug) {
  if (!toolSlug) throw new Error('tool slug is required');
  const data = await post('/tools/execute/COMPOSIO_GET_TOOL_SCHEMAS', {
    arguments: { tool_slugs: [toolSlug] },
    user_id: userId,
  });
  console.log(JSON.stringify(data, null, 2));
}

// connect [toolkit_slug]
// No args: lists all available toolkits from platform auth configs.
// With toolkit: checks if already connected; if not, generates an OAuth link.
async function connect(toolkit) {
  const url = toolkit
    ? `${baseUrl}/connect-configs?toolkit=${encodeURIComponent(toolkit)}`
    : `${baseUrl}/connect-configs`;
  const res = await fetch(url, { headers: baseHeaders() });
  const text = await res.text();
  if (!res.ok) throw new Error(`Composio connect-configs: ${res.status} ${text}`);
  const data = JSON.parse(text);
  console.log(JSON.stringify(data, null, 2));
}

// Toolkit profile actions: maps toolkit slug → { action, field } to fetch account identifier.
const PROFILE_ACTIONS = {
  gmail:           { action: 'GMAIL_GET_PROFILE',            field: d => d?.emailAddress },
  google:          { action: 'GMAIL_GET_PROFILE',            field: d => d?.emailAddress },
  github:          { action: 'GITHUB_GET_THE_AUTHENTICATED_USER', field: d => d?.login },
  slack:           { action: 'SLACK_GET_PROFILE',            field: d => d?.email || d?.display_name },
  twitter:         { action: 'TWITTER_USER_LOOKUP_ME',       field: d => d?.username },
  notion:          { action: 'NOTION_GET_USER',              field: d => d?.name || d?.email },
};

async function fetchProfileAccount(toolkitSlug) {
  const p = PROFILE_ACTIONS[toolkitSlug];
  if (!p) return null;
  try {
    const data = await post('/tools/execute/COMPOSIO_MULTI_EXECUTE_TOOL', {
      arguments: { tools: [{ tool_slug: p.action, arguments: {} }], sync_response_to_workbench: false },
      user_id: userId,
    });
    const response = data?.data?.results?.[0]?.response;
    if (!response?.successful) return null;
    return p.field(response?.data?.response_data) || null;
  } catch {
    return null;
  }
}

// connections [toolkit_slug]
async function connections(toolkit) {
  const query = toolkit ? `&toolkit_slugs=${encodeURIComponent(toolkit)}` : '';
  const res = await fetch(`${API}/connected_accounts?user_ids=${encodeURIComponent(userId)}&statuses=ACTIVE${query}&limit=50`, {
    headers: baseHeaders(),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Composio connected_accounts: ${res.status} ${text}`);
  const data = JSON.parse(text);

  const items = await Promise.all((data.items || []).map(async a => {
    const entry = {
      toolkit: a.toolkit?.slug,
      status: a.status,
      connected: a.status === 'ACTIVE',
    };
    if (a.status === 'ACTIVE') {
      const account = await fetchProfileAccount(a.toolkit?.slug);
      if (account) entry.account = account;
    }
    return entry;
  }));
  console.log(JSON.stringify(items, null, 2));
}

(async () => {
  try {
    switch (cmd) {
      case 'search':      await search(args[0]); break;
      case 'exec':        await exec(args[0], args[1], args[2], args[3]); break;
      case 'schema':      await schema(args[0]); break;
      case 'connections': await connections(args[0]); break;
      case 'connect':     await connect(args[0]); break;
      default:
        console.error('Usage: node composio.js search|exec|schema|connections|connect ...');
        process.exit(1);
    }
  } catch (e) {
    console.error(JSON.stringify({ error: e.message }));
    process.exit(1);
  }
})();
