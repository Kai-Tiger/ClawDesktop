# MEMORY.md — Long-Term Memory

_Curated knowledge that persists across sessions. Not raw logs — distilled signal._

---

## About This Agent

- **Name:** ${AGENT_NAME}
- **Role:** _Fill from IDENTITY.md on first run_
- **Setup date:** _Fill with today's date on first run_
- **Core files:** SOUL.md, IDENTITY.md, PLATFORM_SOP.md, USER.md, TOOLS.md (+ COMPANY.md if applicable)

---

## About the Agent Owner

> [Build this over time — name, preferences, communication style, what they care about, what annoys them]

---

## Context (Company / Project)

> [If applicable — fill from COMPANY.md and conversations as they evolve. Key decisions, pivots, positioning choices. Remove this section if the agent serves an individual user with no business context.]

---

## Key Decisions Log

_What was decided, why, and what was rejected._

| Date | Decision | Rationale | Alternatives Rejected |
|------|----------|-----------|----------------------|
| | | | |

---

## Lessons Learned

_Things that didn't work and why. Patterns to avoid repeating._

---

## Active Projects

_What's in flight right now._

---

## Recurring Preferences

_How the agent owner likes to work, communicate, receive feedback, review drafts._

---

_Review and prune quarterly. Old decisions that no longer apply should be archived, not kept._
_Last updated: [date]_
